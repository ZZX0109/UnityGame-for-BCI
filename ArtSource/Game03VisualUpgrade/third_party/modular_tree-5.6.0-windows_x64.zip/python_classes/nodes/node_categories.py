import nodeitems_utils
from nodeitems_utils import NodeCategory, NodeItem


class MTreeNodeCategory(NodeCategory):
    @classmethod
    def poll(cls, context):
        return context.space_data.tree_type == "mt_MtreeNodeTree"


node_categories = [
    # identifier, label, items list
    MTreeNodeCategory(
        "Mesher",
        "Mesher",
        items=[
            NodeItem("mt_MesherNode"),
        ],
    ),
    MTreeNodeCategory(
        "Trunk",
        "Trunk",
        items=[
            NodeItem("mt_TrunkNode"),
        ],
    ),
    MTreeNodeCategory(
        "Branch",
        "Branch",
        items=[
            NodeItem("mt_BranchNode"),
            NodeItem("mt_GrowthNode"),
        ],
    ),
    MTreeNodeCategory(
        "Leaf",
        "Leaf",
        items=[
            NodeItem("mt_LeafShapeNode"),
        ],
    ),
    MTreeNodeCategory(
        "Modifiers",
        "Modifiers",
        items=[
            NodeItem("mt_PipeRadiusNode"),
        ],
    ),
    MTreeNodeCategory(
        "Property",
        "Property",
        items=[
            NodeItem("mt_RandomPropertyNode"),
            NodeItem("mt_RampPropertyNode"),
        ],
    ),
    MTreeNodeCategory(
        "Export",
        "Export",
        items=[
            NodeItem("mt_PivotPainterExportNode"),
        ],
    ),
]


def register():
    nodeitems_utils.register_node_categories("MTREE_NODES", node_categories)


def unregister():
    nodeitems_utils.unregister_node_categories("MTREE_NODES")
