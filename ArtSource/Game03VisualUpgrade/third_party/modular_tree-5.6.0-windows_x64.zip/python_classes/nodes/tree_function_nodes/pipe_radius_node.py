import bpy

from ...m_tree_wrapper import lazy_m_tree
from ..base_types.node import MtreeFunctionNode


class PipeRadiusNode(bpy.types.Node, MtreeFunctionNode):
    bl_idname = "mt_PipeRadiusNode"
    bl_label = "Radius Override"

    @property
    def tree_function(self):
        return lazy_m_tree.PipeRadiusFunction

    def init(self, context):
        self.add_input("mt_TreeSocket", "Tree", is_property=False)

        self.add_input(
            "mt_FloatSocket",
            "End Radius",
            min_value=0.0001,
            property_name="end_radius",
            property_value=0.005,
        )
        self.add_input(
            "mt_FloatSocket",
            "Constant Growth",
            min_value=0,
            property_name="constant_growth",
            property_value=0.2,
        )
        self.add_input(
            "mt_FloatSocket",
            "Accumulation Power",
            min_value=0.1,
            property_name="power",
            property_value=2.5,
        )

        self.add_output("mt_TreeSocket", "Tree", is_property=False)
